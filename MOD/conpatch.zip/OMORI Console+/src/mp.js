  const cmdSetMp = (handler, args) => {
    if (args.length < 2) {
      handler.log("Usage: /setmp [actor] [value]");
      return;
    }
    let value = args[2] === "max" ? "max" : HandlerHelper.parseInteger(handler, args[2]);
    if (value === null) { return; }

    let actors = HandlerHelper.parseSelectorActors(handler, args[1]);
    for (let actor of actors) {
      let finalValue = value === "max" ? actor.mmp : value;
      actor.setMp(finalValue);
      handler.log(`Set ${actor.name()}'s MP to ${finalValue}`);  
    }
  };
window.commands.forceAdd("mp", cmdSetMp, HandlerHelper.createCustomSuggestionTemplate("ACTOR", "QUANTITY"));
window.commands.forceAdd("setmp", cmdSetMp, HandlerHelper.createCustomSuggestionTemplate("ACTOR", "QUANTITY"));
