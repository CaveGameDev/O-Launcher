if (typeof window.commands !== "undefined") {
  const cmdwTitle = (handler) => {
    document.title = args[1];
   };
    window.commands.add("windowtitle", cmdwTitle);  
    window.commands.add("wtitle", cmdwTitle);
}
