// Todo: what the fuck?

var fuck = 'The main menu title has been set to '+args[2]+'\nNOTE: You might want to reload the game in order to take effect.'
if (typeof window.commands !== "undefined") {
    const plutoOnCommand = (handler, args) => {
        if (args[2] === "Good Ending"){
            DataManager.forceWriteToFile(449)
            handler.log(fuck, "lime");
            return;
        }
        if (args[2] === "Bad Ending"){
            DataManager.forceWriteToFile(448)
            handler.log(fuck, "lime");
            return;
        }
        if (args[2] === "Redspace"){
            DataManager.forceWriteToFile(445)
            handler.log(fuck, "lime");
            return;
        }
        if (args[2] === "Blackspace"){
            DataManager.forceWriteToFile(444)
            handler.log(fuck, "lime");
            return;
        }
        if (args[2] === "Default"){
            DataManager.forceWriteToFile(0)
            handler.log(fuck, "lime"); 
            return;
        }
        
        
      };
  const titleOnSuggestion = (args) => {
      if (args.length === 2) {
          return ["Default","Blackspace","Redspace","Good Ending", "Bad Ending"];
      }
      return [];
  };
      window.commands.add("title", titleOnCommand);

}

