const cmdAddState = (handler, args) => {
    if (args.length < 2) {
      handler.log("Usage: /addstate [actor] [id]");
      return;
    }
    let state = HandlerHelper.parseState(handler, args[2]);
    if (state === null) { return; }

    let actors = HandlerHelper.parseSelectorActors(handler, args[1]);
    for (let actor of actors) {
      actor.addState(state.id);
      handler.log(`Added state ${state.name} to ${actor.name()}`);  
    }
  window.commands.forceAdd("addstate", cmdAddState, HandlerHelper.createCustomSuggestionTemplate("ACTOR", "STATE"));
  };

