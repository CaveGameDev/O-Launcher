/* Console+ boot check - patched for the web port: the beta-warning
 * confirm() and the missing-console / Console++ alert()s were removed
 * so the mod loads silently without nagging or killing the game. */
function $consoleproceedanyways() {}
