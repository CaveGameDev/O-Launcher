  const cmdSetMpEnemy = (handler, args) => {
    if (args.length < 2) {
      handler.log("Usage: /setmpenemy [enemy] [value]");
      return;
    }
    let value = args[2] === "max" ? "max" : HandlerHelper.parseInteger(handler, args[2]);
    if (value === null) { return; }

    let enemies = HandlerHelper.parseSelectorEnemies(handler, args[1]);
    for (let enemy of enemies) {
      let finalValue = value === "max" ? enemy.mmp : value;
      enemy.setMp(finalValue);
      handler.log(`Set ${enemy.name()}'s MP to ${finalValue}`);  
    }
 window.commands.forceAdd("mpenemy", cmdSetMpEnemy, HandlerHelper.createCustomSuggestionTemplate("ENEMY", "QUANTITY"));
 window.commands.forceAdd("setmpenemy", cmdSetMpEnemy, HandlerHelper.createCustomSuggestionTemplate("ENEMY", "QUANTITY"));
  };


