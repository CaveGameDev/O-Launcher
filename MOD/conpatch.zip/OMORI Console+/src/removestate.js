  const cmdRemoveState = (handler, args) => {
    if (args.length < 2) {
      handler.log("Usage: /removestate [actor] [id]");
      return;
    }
    let state = HandlerHelper.parseState(handler, args[2]);
    if (state === null) { return; }

    let actors = HandlerHelper.parseSelectorActors(handler, args[1]);
    for (let actor of actors) {
      actor.removeState(state.id);
      handler.log(`Added state ${state.name} to ${actor.name()}`);  
    }
  window.commands.forceAdd("removestate", cmdRemoveState, HandlerHelper.createCustomSuggestionTemplate("ACTOR", "STATE"));
  };

