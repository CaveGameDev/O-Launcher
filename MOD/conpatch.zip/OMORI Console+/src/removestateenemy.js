 const cmdRemoveStateEnemy = (handler, args) => {
    if (args.length < 2) {
      handler.log("Usage: /removestateenemy [enemy] [id]");
      return;
    }
    let state = HandlerHelper.parseState(handler, args[2]);
    if (state === null) { return; }

    let enemies = HandlerHelper.parseSelectorEnemies(handler, args[1]);
    for (let enemy of enemies) {
      enemy.removeState(state.id);
      handler.log(`Added state ${state.name} to ${enemy.name()}`);  
    }
  window.commands.forceAdd("removestateenemy", cmdRemoveStateEnemy, HandlerHelper.createCustomSuggestionTemplate("ENEMY", "STATE"));
  };
