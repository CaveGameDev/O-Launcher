const kenwayButton = (handler) => {
    $gameParty.gainGold(60);
    handler.log(`60 dollars.`);
};


