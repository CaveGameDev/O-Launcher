if (typeof window.commands !== "undefined") {

    const doNothingOnCommand = (handler) => 

  };
    window.commands.add("donothing", doNothingOnCommand);
}
