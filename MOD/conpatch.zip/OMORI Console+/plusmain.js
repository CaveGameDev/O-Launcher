handler.log("Welcome to Console+.");
/*/
var betawarning = `This is a BETA version of Console+. I haven't properly tested most of the stuff on here. Things could break, so make a back up of your save files. If you don't want that, then get the 0.5.0 version. Should you have any feedback or bugs you wanna report, you can do so by typing in \"/feedback\" in the console. Are you sure you want to continue?`

if (!confirm(betawarning)) {
SceneManager.terminate();
}
/*/
// Catch every possible error because i suck at programming, and i refuse to vibecode this.






// 3. Check OMORI Console (OG)
/*/
if (!$modLoader.mods.get("console")) {
alert('Error. You do not have the OG console mod installed. Visit https://mods.one/mod/console to get it.');
}

// 4. Check OMORI Console++
if ($modLoader.mods.get("consoleplusplus")) {
alert('Console++ (not to be confused with Console+) is not compatible with this mod. please remove it.');
handler.log("Console++ (not to be confused with Console+) is not compatible with this mod. please remove it.", "red");
}
/*/

(function(){
    var oldLog = console.log;
    console.log = function (message) {
                handler.log(message);
    };
})();

(function(){
    var oldWarnLog = console.warn;
    console.warn = function (message) {
                handler.log(message, "yellow");
    };
})();

(function(){
    var oldWarnLog = console.warn;
    console.error = function (message) {
                handler.error(message, "error");
    };
})();

