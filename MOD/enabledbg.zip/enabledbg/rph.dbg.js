// enabledbg — browser rewrite of the desktop "Enable Debugger" mod.
//
// The desktop version decrypted a Steam-encrypted copy of the debugger plugin
// (YEP_Debugger.OMORI) and eval'd it. That payload isn't shipped in the web
// build, and YEP_Debugger.js already ships unencrypted here — it's just
// disabled ($plugins status:false) and gated behind playtest mode. So this
// script re-enables it and flips the two playtest flags it checks.
(function () {
    'use strict';

    // YEP_Debugger.js wraps its entire body in
    //   if (Utils.isNwjs() && Utils.isOptionValid('test')) { ... }
    // and Game_Temp.isPlaytest() (fed by the same check) gates the F9 menu.
    // Utils.isNwjs() already returns true in the browser (nw + process shims),
    // so we only need to force the 'test' option.
    if (typeof Utils !== 'undefined' && typeof Utils.isOptionValid === 'function') {
        var _origIsOptionValid = Utils.isOptionValid;
        Utils.isOptionValid = function (name) {
            if (name === 'test') return true;
            return _origIsOptionValid(name);
        };
    }

    if (typeof Game_Temp !== 'undefined' && Game_Temp.prototype) {
        Game_Temp.prototype.isPlaytest = function () {
            return true;
        };
    }

    // Re-enable the disabled YEP_Debugger entry before PluginManager.setup()
    // builds its load chain (this runs at the pre_game_start stage).
    if (typeof $plugins !== 'undefined') {
        var dbg = $plugins.filter(function (p) {
            return p && p.name && String(p.name).toLowerCase() === 'yep_debugger';
        })[0];
        if (dbg) {
            dbg.status = true;
            console.log('[enabledbg] YEP_Debugger enabled; playtest flags forced.');
        } else {
            console.warn('[enabledbg] YEP_Debugger not found in $plugins.');
        }
    }
})();
