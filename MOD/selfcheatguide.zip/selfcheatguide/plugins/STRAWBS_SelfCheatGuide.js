// Mod conflicts -- Detect the Name Changer mod on start-up
if ($modLoader.mods.get("name_changer")) {
	alert("The functionality of the Name Changer mod is included in Self-Cheat Guide. It is recommended to remove Name Changer.")
}

// Name Changer impl. -- increase entry box width
Window_OmoriNameInputName.prototype.windowWidth = function() {
	return 362;
};